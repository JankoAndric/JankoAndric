package tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.MainPage;
import utillities.PropertyManager;

public class LogInTest extends BaseTest{
    @Test
    public void logIn() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.
                performLogIn(PropertyManager.getInstance().getValidUsername(),
                PropertyManager.
                        getInstance().
                        getValidPassword());
        MainPage mainPage = new MainPage(driver);
        mainPage.
                verifyLogIn("Products");
    }
}
