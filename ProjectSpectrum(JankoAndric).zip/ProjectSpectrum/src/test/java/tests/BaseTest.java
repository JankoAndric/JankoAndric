package tests;

import common.BrowserSetup;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import utillities.PropertyManager;

public class BaseTest extends BrowserSetup {
    @Parameters({"browser"})
    @BeforeMethod
    public void setup(@Optional("chrome") String browser) {
        switch(browser.
                toLowerCase()){
            case "chrome":
                startChrome();
                break;
            case "firefox":
                startFirefox();
                break;
            default:
                startChrome();
        }
        driver.
                get(PropertyManager.getInstance().getUrl());
    }
    @AfterMethod
   public void tearDown(){driver.quit();}
    public WebDriver getDriver(){
        return driver;
    }
}
