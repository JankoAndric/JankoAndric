package tests;

import dataProvider.DataProviders;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.LoginPage;

public class FailedLogInTest extends BaseTest{
    @Test(dataProvider = "FailedLogInDataList", dataProviderClass = DataProviders.class)
    public void failedLogIn(String username, String password, String error){
        LoginPage loginPage = new LoginPage (driver);
        loginPage.
                performLogIn(username, password);
        loginPage.
                verifyFailedLogin(error);
    }
}
