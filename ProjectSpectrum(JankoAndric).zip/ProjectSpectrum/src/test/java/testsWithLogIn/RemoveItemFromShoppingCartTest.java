package testsWithLogIn;

import org.testng.annotations.Test;
import pages.MainPage;
import pages.ShoppingCartPage;

public class RemoveItemFromShoppingCartTest extends BaseTestWithLogIn{
    @Test
    public void removeItemFromShoppingCart(){
        MainPage mainPage = new MainPage(driver);
        mainPage.
                addBackpackToCart();
        mainPage.
                verifyAnItemIsInTheCart("1");
        mainPage.
                navigateToShoppingCart();
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.
                verifySpecificItemIsInTheCart("Sauce Labs Backpack");
        shoppingCartPage.
                removeItemFromCart();
        shoppingCartPage.
                confirmationThatTheresNoProductInTheCart();
        shoppingCartPage.
                navigateToMainPage();
        mainPage.
                verifyLogIn("Products");
        mainPage.
                verifyThatTheresNoRedBadgeOnCartIcon();
        mainPage.
                addToCartButtonOnBackpackProduct("Add to cart");

    }


}
