package testsWithLogIn;

import org.testng.annotations.Test;
import pages.*;
import utillities.PropertyManager;

public class AddItemToCartAndBuyItTest extends BaseTestWithLogIn{
    @Test
    public void addItemAndBuyIt(){
        MainPage mainPage = new MainPage(driver);
        String addedItemName = mainPage.addRandomItemToCart();
        mainPage.
                verifyAnItemIsInTheCart("1");
        mainPage.
                navigateToShoppingCart();
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.
                verifySpecificItemIsInTheCart(addedItemName);
        shoppingCartPage.
                navigateToCheckout();
        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.
                verifyCorrectTitleOnCheckoutPage("Checkout: Your Information");
        checkoutPage.
                enterCredentials(
                PropertyManager.getInstance().
                        getFirstName(),
                PropertyManager.getInstance().
                        getLastName(),
                PropertyManager.getInstance().
                        getZipCode());
        FinishPage finishPage = new FinishPage(driver);
        finishPage.
                verifyCorrectTitleOnFinishPage("Checkout: Overview");
        finishPage.
                navigateToCompleteOrderPage();
        CompleteOrderPage completeOrderPage = new CompleteOrderPage(driver);
        completeOrderPage.
                verifyCompleteHeaderOnCompleteOrderPage("Thank you for your order!");
        completeOrderPage.
                navigateToMainPage();
        mainPage.
                verifyThatTheresNoRedBadgeOnCartIcon();
        mainPage.
                verifyLogIn("Products");
    }
}
