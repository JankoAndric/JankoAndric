package testsWithLogIn;

import org.testng.annotations.Test;
import pages.MainPage;
import pages.ShoppingCartPage;

public class RemoveItemFromMainPageTest extends BaseTestWithLogIn{
    @Test
    public void removeItemFromMainPage(){
        MainPage mainPage = new MainPage(driver);
        mainPage.
                addBackpackToCart();
        mainPage.
                verifyAnItemIsInTheCart("1");
        mainPage.
                removeButtonOnBackpackProduct("Remove");
        mainPage.
                removeBackpackFromMainPage();
        mainPage.
                verifyThatTheresNoRedBadgeOnCartIcon();
        mainPage.
                addToCartButtonOnBackpackProduct("Add to cart");
        ShoppingCartPage shoppingCartPage = new ShoppingCartPage(driver);
        shoppingCartPage.
                confirmationThatTheresNoProductInTheCart();
    }
}
