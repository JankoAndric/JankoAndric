package testsWithLogIn;

import org.testng.annotations.Test;
import pages.LoginPage;
import pages.MainPage;

public class LogOutTest extends BaseTestWithLogIn{
    @Test
    public void logOutTest(){
        MainPage mainPage = new MainPage(driver);
        mainPage.
                performLogOut();
        LoginPage loginPage = new LoginPage(driver);
        loginPage.
                verifyLogOut("Login");
    }
}
