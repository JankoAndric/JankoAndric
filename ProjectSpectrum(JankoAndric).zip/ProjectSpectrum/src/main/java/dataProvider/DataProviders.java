package dataProvider;

import org.testng.annotations.DataProvider;

public class DataProviders {
    @DataProvider(name = "FailedLogInDataList")
    public Object[][] getDataFromDataProvider(){
        return new Object[][]
                {
                        {"", "secret_sauce", "Epic sadface: Username is required"},
                        {"performance_glitch_user", "", "Epic sadface: Password is required"},
                        {"USER123", "password987", "Epic sadface: Username and password do not match any user in this service"}
                };
    }
}
