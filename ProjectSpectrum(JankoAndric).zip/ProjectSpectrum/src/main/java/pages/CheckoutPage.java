package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CheckoutPage extends BasePage{
    public CheckoutPage(WebDriver driver) {
        super(driver);
    }
    By titleNameBy = By.className("title");
    By firstNameBy = By.id("first-name");
    By lastNameBy = By.id("last-name");
    By zipCodeBy = By.id("postal-code");
    By continueButtonBy = By.id("continue");
    public void verifyCorrectTitleOnCheckoutPage(String expectedText){
        Assert.
                assertEquals(readTextFromElement(titleNameBy), expectedText);
    }
    public void enterCredentials(String firstName, String lastName, String zipCode){
        writeText(firstNameBy, firstName);
        writeText(lastNameBy, lastName);
        writeText(zipCodeBy, zipCode);
        clickElement(continueButtonBy);

    }
}
