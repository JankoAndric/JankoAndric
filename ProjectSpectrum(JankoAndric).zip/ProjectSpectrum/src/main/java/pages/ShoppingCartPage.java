package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import static org.openqa.selenium.By.tagName;

public class ShoppingCartPage extends BasePage {

    public ShoppingCartPage(WebDriver driver) {
        super(driver);
    }
    By shoppingCartItemNameBy = By.className("inventory_item_name");
    By checkoutButtonBy = By.id("checkout");
    By removeBackpackButtonBy = By.id("remove-sauce-labs-backpack");
    By continueShoppingButtonBy = By.id("continue-shopping");
    By itemInShoppingCartBy = By.className("cart_item");
    public void verifySpecificItemIsInTheCart(String expectedText){
        Assert.
                assertEquals(readTextFromElement(shoppingCartItemNameBy), expectedText);
    }
    public void navigateToCheckout(){
        clickElement(checkoutButtonBy);
    }
    public void removeItemFromCart(){clickElement(removeBackpackButtonBy);}
    public void navigateToMainPage(){clickElement(continueShoppingButtonBy);}
    public void confirmationThatTheresNoProductInTheCart(){
        Assert.
                assertTrue(waitForElementToDisappear(itemInShoppingCartBy));
    }

}
