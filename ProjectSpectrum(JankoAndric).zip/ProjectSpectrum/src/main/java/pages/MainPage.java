package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class MainPage extends BasePage {

    public MainPage(WebDriver driver) {
        super(driver);
    }
    By productsTitlleBy = By.className("title");
    By burgerMenuButtonBy = By.id("react-burger-menu-btn");
    By logOutButtonBy = By.id("logout_sidebar_link");
    //By tShirtButtonBuyBy = By.id("add-to-cart-sauce-labs-bolt-t-shirt");
    By shoppingCartButtonBy = By.className("shopping_cart_link");
    By badgeOnShoppingCartBy = By.className("shopping_cart_badge");
    By backapckButtonBuyBy = By.id("add-to-cart-sauce-labs-backpack");
    By backpackRemoveButtonBy = By.id("remove-sauce-labs-backpack");
    By allItemsElementsBy = By.className("inventory_item");
    By productNameBy = By.className("inventory_item_name");
    By redBadgeOnCartIconBy = By.className("shopping_cart_badge");
    public void verifyLogIn(String expectedText){
        Assert.
                assertEquals(readTextFromElement(productsTitlleBy), expectedText);
    }
    public void performLogOut(){
        clickElement(burgerMenuButtonBy);
        clickElement(logOutButtonBy);
    }
    /*public void addTShirtToCart(){
        clickElement(tShirtButtonBuyBy);*//*
    }*/
    public void verifyAnItemIsInTheCart(String expectedText){
        Assert.
                assertEquals(readTextFromElement(badgeOnShoppingCartBy), expectedText);
    }
    public void navigateToShoppingCart(){clickElement(shoppingCartButtonBy);}
    public void addBackpackToCart(){clickElement(backapckButtonBuyBy);}
    public void addToCartButtonOnBackpackProduct(String expectedText){
        Assert.
                assertEquals(readTextFromElement(backapckButtonBuyBy), expectedText);
    }
    public void removeButtonOnBackpackProduct(String expectedText){
        Assert.
                assertEquals(readTextFromElement(backpackRemoveButtonBy), expectedText);
    }
    public void removeBackpackFromMainPage(){clickElement(backpackRemoveButtonBy);}
    public String addRandomItemToCart(){
        WebElement itemInAList = selectRandomWebElement(allItemsElementsBy);
        String itemName = itemInAList.
                findElement(productNameBy).
                getText();
        itemInAList.
                findElement(By.tagName("button")).
                click();
        return itemName;
    }
    public void verifyThatTheresNoRedBadgeOnCartIcon(){
        Assert.
                assertTrue(waitForElementToDisappear(redBadgeOnCartIconBy));
    }
}

