package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CompleteOrderPage extends BasePage{
    public CompleteOrderPage(WebDriver driver) {
        super(driver);
    }
    By completeOrderHeaderBy = By.className("complete-header");
    By backHomeButtonBy = By.id("back-to-products");
    public void verifyCompleteHeaderOnCompleteOrderPage(String expectedText){
        Assert.
                assertEquals(readTextFromElement(completeOrderHeaderBy), expectedText);
    }
    public void navigateToMainPage(){clickElement(backHomeButtonBy);
    }
}
