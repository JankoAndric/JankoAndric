package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class FinishPage extends BasePage{
    public FinishPage(WebDriver driver) {
        super(driver);
    }
    By tittleNameOnFinishPageBy = By.className("title");
    By finishButtonBy = By.id("finish");
    public void verifyCorrectTitleOnFinishPage(String expectedText){
        Assert.
                assertEquals(readTextFromElement(tittleNameOnFinishPageBy), expectedText);
    }
    public void navigateToCompleteOrderPage(){clickElement(finishButtonBy);}
}
