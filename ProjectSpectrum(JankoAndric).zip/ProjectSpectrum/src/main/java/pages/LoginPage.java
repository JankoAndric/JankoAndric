package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class LoginPage extends BasePage {
    public LoginPage(WebDriver driver){super(driver);}
    By usernameFieldBy = By.id("user-name");
    By passwordFieldBy = By.id("password");
    By logInButtonBy = By.id("login-button");
    By errorNotificationBy = By.xpath("//h3[@data-test='error']");
    public void performLogIn(String username, String password){
        writeText(usernameFieldBy, username);
        writeText(passwordFieldBy, password);
        clickElement(logInButtonBy);
    }
    public void verifyFailedLogin(String expectedText){
        Assert.assertEquals(readTextFromElement(errorNotificationBy), expectedText);
    }
    public void verifyLogOut(String expectedText){
        Assert.assertEquals(readAttributeAsText(logInButtonBy, "value"), expectedText);
    }

}
